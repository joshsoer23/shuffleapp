<section id="footer">
    <img src="images/SundaeMediaLogo.png" width="100%" height="" alt="sundae media logo" />
    <p>Powered by Sundae Media</p>
</section>